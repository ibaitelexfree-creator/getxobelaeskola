import ResultsClient from './ResultsClient';

export default function ResultsPage() {
    return <ResultsClient />;
}
