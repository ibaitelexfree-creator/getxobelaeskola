'use client';

import MontessoriExplorer from '@/components/academy/montessori/MontessoriExplorer';
import { getAllTopics } from '@/components/academy/montessori/data-adapter';
import React, { useState, useEffect } from 'react';

export default function MontessoriPage() {
    const [topics, setTopics] = useState<any[]>([]);
    const [history, setHistory] = useState<any[]>([]);

    useEffect(() => {
        setTopics(getAllTopics());
    }, []);

    const handleRecordInteraction = (topicId: string, result: 'success' | 'failure') => {
        setHistory(prev => [...prev, { topicId, result, timestamp: Date.now() }]);
    };

    return (
        <main className="min-h-screen bg-nautical-deep py-8 md:py-12">
            <MontessoriExplorer
                topics={topics}
                history={history}
                ability={0.5}
                recommendedTopic={topics[0] || null}
                onRecordInteraction={handleRecordInteraction}
            />
        </main>
    );
}
