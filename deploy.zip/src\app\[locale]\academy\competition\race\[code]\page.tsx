import RaceClient from './RaceClient';

export default function RacePage() {
    return <RaceClient />;
}
