
import React from 'react';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { ShieldAlert, Anchor } from 'lucide-react';

export default function UnauthorizedPage() {
    const t = useTranslations('errors.403');
    const { locale } = useParams();

    return (
        <div className="min-h-screen bg-nautical-deep flex items-center justify-center p-4 relative overflow-hidden">
            {/* Background decorative elements */}
            <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
                <div className="absolute -top-4 -left-4 w-96 h-96 bg-accent rounded-full blur-[120px]" />
                <div className="absolute -bottom-4 -right-4 w-96 h-96 bg-blue-500 rounded-full blur-[120px]" />
            </div>

            <div className="max-w-md w-full text-center relative z-10">
                <div className="mb-8 flex justify-center">
                    <div className="w-24 h-24 bg-white/5 rounded-full flex items-center justify-center border border-white/10 backdrop-blur-sm animate-pulse">
                        <ShieldAlert className="w-12 h-12 text-accent" />
                    </div>
                </div>

                <h1 className="text-4xl font-black text-white mb-4 tracking-tighter uppercase italic">
                    {t('title') || 'Acceso Restringido'}
                </h1>

                <p className="text-white/60 mb-8 leading-relaxed">
                    {t('description') || 'No tienes los permisos necesarios para navegar estas aguas. Por favor, regresa a puerto seguro.'}
                </p>

                <div className="space-y-4">
                    <Link
                        href="/"
                        className="flex items-center justify-center gap-2 w-full bg-accent hover:bg-accent/90 text-nautical-black font-black py-4 rounded-xl transition-all transform hover:scale-[1.02] active:scale-95 uppercase tracking-widest text-sm"
                    >
                        <Anchor className="w-4 h-4" />
                        Volver a la Escuela
                    </Link>

                    <Link
                        href="/login"
                        className="block w-full text-white/40 hover:text-white text-xs font-bold uppercase tracking-widest transition-colors py-2"
                    >
                        Cambiar de Cuenta
                    </Link>
                </div>
            </div>
        </div>
    );
}
