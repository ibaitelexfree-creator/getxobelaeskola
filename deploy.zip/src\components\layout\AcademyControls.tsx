export default function AcademyControls() {
    return null;
}
