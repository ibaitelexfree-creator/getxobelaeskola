
import { NextResponse } from 'next/server';
import { NotionSyncService } from '@/lib/notion-sync-service';

export async function POST(req: Request) {
    const { searchParams } = new URL(req.url);
    const secret = searchParams.get('secret');
    const mode = searchParams.get('mode') || 'pull'; // 'pull' (SB->Notion) or 'push' (Notion->SB)
    const table = searchParams.get('table');

    if (secret !== 'getxo_notion_sync_2026_pro') {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    try {
        const body = await req.json().catch(() => ({}));
        const rowId = body?.record?.id || body?.id;
        const tableName = table || body?.table;

        if (!tableName) {
            return NextResponse.json({ error: 'Missing table name' }, { status: 400 });
        }

        if (mode === 'pull') {
            if (rowId) {
                // Return immediately and run sync in background for single row
                NotionSyncService.syncSupabaseToNotion(tableName, rowId);
                return NextResponse.json({ message: `Syncing row ${rowId} from ${tableName} to Notion` });
            } else {
                // Full table sync
                NotionSyncService.syncFullTableToNotion(tableName);
                return NextResponse.json({ message: `Full sync started for table ${tableName}` });
            }
        } else if (mode === 'push') {
            // Logic for updates coming FROM Notion (triggered by n8n or webhook)
            if (body?.properties) {
                NotionSyncService.syncNotionToSupabase(tableName, body);
                return NextResponse.json({ message: `Syncing Notion page back to ${tableName}` });
            }
        }

        return NextResponse.json({ message: 'Sync request received' });
    } catch (err: any) {
        console.error('API Sync Route Error:', err);
        return NextResponse.json({ error: err.message }, { status: 500 });
    }
}
