import createMiddleware from 'next-intl/middleware';
import { createServerClient } from '@supabase/ssr';
import { type NextRequest, NextResponse } from 'next/server';

const intlMiddleware = createMiddleware({
    locales: ['es', 'eu', 'en', 'fr'],
    defaultLocale: 'es',
    localePrefix: 'always'
});

export default async function middleware(request: NextRequest) {
    const { nextUrl } = request;
    const path = nextUrl.pathname;

    // 1. Run next-intl middleware first
    const response = intlMiddleware(request);

    // If it's a redirect, return it immediately
    if (response.status === 307 || response.status === 308) {
        return response;
    }

    // 2. Supabase session logic
    const supabase = createServerClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
        {
            cookies: {
                getAll() {
                    return request.cookies.getAll();
                },
                setAll(cookiesToSet) {
                    cookiesToSet.forEach(({ name, value }) => {
                        request.cookies.set(name, value);
                    });
                    cookiesToSet.forEach(({ name, value, options }) => {
                        response.cookies.set(name, value, options);
                    });
                },
            },
        }
    );

    const { data: { user } } = await supabase.auth.getUser();

    // 3. Admin / Staff Protection (Task T-001)
    // Match /admin or /[locale]/admin
    const isAdminPath = path.includes('/admin');
    const isApiAdminPath = path.includes('/api/admin');

    if (isAdminPath || isApiAdminPath) {
        if (!user) {
            const loginUrl = new URL('/login', request.url);
            return NextResponse.redirect(loginUrl);
        }

        // Fetch profile to checking role
        // Note: In a real high-traffic app, we'd use JWT custom claims
        const { data: profile } = await supabase
            .from('profiles')
            .select('rol')
            .eq('id', user.id)
            .single();

        if (!profile || (profile.rol !== 'admin' && profile.rol !== 'instructor')) {
            // Redirect students or unknown roles trying to access admin
            if (isApiAdminPath) {
                return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
            }
            const unauthorizedUrl = new URL('/unauthorized', request.url);
            return NextResponse.redirect(unauthorizedUrl);
        }
    }

    return response;
}

export const config = {
    matcher: ['/((?!api|_next|_vercel|.*\\..*).*)']
};
